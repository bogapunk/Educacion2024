<!DOCTYPE html>
<html>
<head>
<title>Registro y Login sistema con PHP MySQL</title>
<link rel="stylesheet" href="style.css" type="text/css" media="all" />
<link rel="stylesheet" href="//fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900" 	type="text/css" media="all">
<!-- Último minificado bootstrap css -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<!-- jQuery libraria incluida -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
<!-- Último minificado bootstrap js -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style>
.btn-success {
	margin: 10px;
}
.main {
	margin: 20px;
}
</style>
</head>
<body>
<div class="main">
<div class="panel panel-default">
<div class="panel-heading">
  <ul class="nav nav-pills">
    <li role="presentation" class="active"><a href="index.php">Inicio</a></li>
  </ul>
</div>
<div class="panel-body">
<div class="row">